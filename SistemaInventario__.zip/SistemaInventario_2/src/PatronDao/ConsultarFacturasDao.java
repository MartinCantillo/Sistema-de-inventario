/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package PatronDao;

import Entidades.Entidad_Cliente;
import Entidades.Entidad_Facturav;

/**
 *
 * @author marti
 */
public interface ConsultarFacturasDao {
    
    public void ExtraerCLienteBD(Entidad_Cliente cliente);
}
