/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package PatronDao;

import Entidades.*;
import javax.swing.JTable;

/**
 *
 * @author marti
 */
public interface inventario_productosDao {
    
    public void ExtraerProductoBD(JTable a);
}
